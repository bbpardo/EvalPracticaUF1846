import PanelAdmin from "../../components/PanelAdmin/PanelAdmin";

function Panel () {
    return (
        <PanelAdmin />
    )
}

export default Panel