export class Article{
    constructor({Articles_id, Name, Photo}){
        this.Articles_id = Articles_id;
        this.Name = Name;
        this.Photo = Photo;
        this.Quantity= 1
    }
}